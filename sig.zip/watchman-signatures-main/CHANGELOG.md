## 2024-04-26
### Added
- Signatures now support Stack Overflow Watchman
  - Tests added for the new Stack Overflow Watchman format

## 2023-12-22
### Added
- Added signatures for:
  - Alibaba
  - Akamai